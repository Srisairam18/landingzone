
# Exam AZ-103/104: Microsoft Azure Administrator Crash Course

### Instructor contact

Tim Warner

* [Twitter](https://twitter.com/techtrainertim)
* [Pluralsight author page](https://www.pluralsight.com/authors/tim-warner)
* [Personal website](https://techtrainertim.com/)

![AZ-103-cover-image](./cover.png)
