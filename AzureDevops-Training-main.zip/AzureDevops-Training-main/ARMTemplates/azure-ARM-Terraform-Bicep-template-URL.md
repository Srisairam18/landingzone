https://learn.microsoft.com/en-us/azure/templates/

Link for Azure ARM , Terraform , Bicep templates
