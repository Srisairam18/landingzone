﻿namespace coreservice114
{
    public class coreservice
    {
        public string Display()
        {
            return "this has core functions";
        }
    }
}