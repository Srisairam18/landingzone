

https://docs.docker.com/desktop/install/windows-install/

https://learn.microsoft.com/en-us/windows/wsl/install
